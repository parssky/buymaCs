const mysql = require('mysql')

var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'codemode1_parssky',
    password : 'Parsa@500',
    database : 'codemod1_buyma_db'
  });

  connection.connect(function(err) {
    if (err) {
      console.error('error connecting: ' + err.stack);
      return;
    }
   
    console.log('DataBase connected as id ' + connection.threadId);
  });

  module.exports = connection
  